# MY Songs List 

This Android app Demeonstrate, How to parse json data (REST API)  into android application using Volley Library to display in RcyclerView.This app is source code for Online Tutorial series available on SmallAcademy.  

# Final App

[![Watch Now](https://img.youtube.com/vi/e3MDW87mbR8/maxresdefault.jpg)](https://www.youtube.com/playlist?list=PLlGT4GXi8_8eo127jp2-GeV0B5BlqF8Lf)
